#!/bin/bash

DIRECTORY=~/openai.js # 存储库的本地路径
DEST_FILE=$DIRECTORY/ip_geo.txt # 目标文件路径
DEST_FILE80=$DIRECTORY/ip_80.txt
COMMIT_MESSAGE="Update ip_geo.txt ip_80.txt" # 提交信息

cp /root/cfipopw/ip-80.txt $DEST_FILE80