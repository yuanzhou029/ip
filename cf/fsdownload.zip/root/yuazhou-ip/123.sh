#!/bin/bash

# 检查 iip.txt 文件是否存在
if [ ! -f "iip.txt" ]; then
  echo "Error: iip.txt 文件不存在."
  exit 1
fi

# 使用 sort 和 uniq 命令去重 IP 地址
sort iip.txt | uniq > 123.txt

echo "去重后的 IP 地址已保存到 123.txt 文件中."
