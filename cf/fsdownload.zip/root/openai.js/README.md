直接复制代码到CF的指定JS文件中，必须域名为https://gptai.yh-iot.cc# openai.js

openwrt优选IP的脚本 

curl -ksSL https://gitlab.com/rwkgyg/cdnopw/raw/main/cdnopw.sh -o cdnopw.sh && bash cdnopw.sh

